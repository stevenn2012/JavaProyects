package co.edu.usa.ingesoft2.granReto;

public class GranRetoException extends Exception
{

   /**
    * 
    */
   private static final long serialVersionUID = 5500347812808643853L;

   public GranRetoException()
   {
      // TODO Auto-generated constructor stub
   }

   public GranRetoException( String message )
   {
      super( message );
      // TODO Auto-generated constructor stub
   }

   public GranRetoException( Throwable cause )
   {
      super( cause );
      // TODO Auto-generated constructor stub
   }

   public GranRetoException( String message, Throwable cause )
   {
      super( message, cause );
      // TODO Auto-generated constructor stub
   }

   public GranRetoException( String message, Throwable cause, boolean enableSuppression,
            boolean writableStackTrace )
   {
      super( message, cause, enableSuppression, writableStackTrace );
      // TODO Auto-generated constructor stub
   }

}
